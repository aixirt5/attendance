import { useEffect, useState, useCallback } from 'react'
import type { DateRange } from '@/lib/supabase'

interface DateRangeFilterProps {
  onChange: (dateRange: DateRange) => void
}

function getDefaultDateRange() {
  const today = new Date()
  const previousMonth = new Date(today)
  previousMonth.setMonth(previousMonth.getMonth() - 1)
  
  return {
    fromDate: previousMonth.toISOString().split('T')[0],
    toDate: today.toISOString().split('T')[0]
  }
}

export default function DateRangeFilter({ onChange }: DateRangeFilterProps) {
  const defaultRange = getDefaultDateRange()
  const [fromDate, setFromDate] = useState(defaultRange.fromDate)
  const [toDate, setToDate] = useState(defaultRange.toDate)
  const [debouncedUpdate, setDebouncedUpdate] = useState<NodeJS.Timeout>()

  const updateDateRange = useCallback(() => {
    if (fromDate || toDate) {
      onChange({ fromDate, toDate })
    }
  }, [fromDate, toDate, onChange])

  // Initial load - trigger the onChange with default date range
  useEffect(() => {
    updateDateRange()
  }, []) // Empty dependency array for initial load only

  // Handle date changes with debouncing
  useEffect(() => {
    if (debouncedUpdate) {
      clearTimeout(debouncedUpdate)
    }

    const timeoutId = setTimeout(() => {
      updateDateRange()
    }, 300) // 300ms debounce

    setDebouncedUpdate(timeoutId)

    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId)
      }
    }
  }, [fromDate, toDate, updateDateRange])

  return (
    <div className="flex items-end space-x-4 mb-6">
      <div className="flex-1">
        <label htmlFor="fromDate" className="block text-sm font-medium text-blue-200 mb-2 pl-1">
          From Date
        </label>
        <div className="input-container">
          <div className="input-icon">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
          <input
            type="date"
            id="fromDate"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            className="input-field pl-10"
            max={toDate || undefined}
          />
        </div>
      </div>

      <div className="flex-1">
        <label htmlFor="toDate" className="block text-sm font-medium text-blue-200 mb-2 pl-1">
          To Date
        </label>
        <div className="input-container">
          <div className="input-icon">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
          <input
            type="date"
            id="toDate"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            className="input-field pl-10"
            min={fromDate || undefined}
          />
        </div>
      </div>

      <button
        onClick={() => {
          // Reset to default date range (last 30 days)
          const defaultRange = getDefaultDateRange()
          setFromDate(defaultRange.fromDate)
          setToDate(defaultRange.toDate)
          onChange(defaultRange)
        }}
        className="px-4 py-3 text-sm font-medium text-blue-200 glass-morphism rounded-lg border border-blue-500/20 hover:border-blue-500/40 transition-colors"
      >
        Reset to Default
      </button>
    </div>
  )
} 