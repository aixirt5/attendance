import { useState } from 'react'
import type { AttendanceRecord } from '@/lib/supabase'

interface AttendanceTableProps {
  records?: AttendanceRecord[]  // Make records optional
  onDelete: (id: string) => Promise<void>
  isLoading?: boolean
}

export default function AttendanceTable({ 
  records = [],  // Provide default empty array
  onDelete,
  isLoading = false
}: AttendanceTableProps) {
  const [sortField, setSortField] = useState<keyof AttendanceRecord>('date')
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc')
  const [selectedRecord, setSelectedRecord] = useState<string | null>(null)

  const handleSort = (field: keyof AttendanceRecord) => {
    if (field === sortField) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('asc')
    }
  }

  // Ensure records is an array before spreading
  const recordsArray = Array.isArray(records) ? records : []
  
  const sortedRecords = [...recordsArray].sort((a, b) => {
    if (a[sortField] === null) return 1
    if (b[sortField] === null) return -1
    if (a[sortField] < b[sortField]) return sortDirection === 'asc' ? -1 : 1
    if (a[sortField] > b[sortField]) return sortDirection === 'asc' ? 1 : -1
    return 0
  })

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  if (isLoading) {
    return (
      <div className="overflow-x-auto glass-morphism rounded-lg">
        <table className="min-w-full divide-y divide-blue-500/20">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">Overtime</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">Job Order</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">Destination</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">Details</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-blue-500/20">
            {[1, 2, 3].map((_, index) => (
              <tr key={index} className="animate-pulse">
                <td className="px-6 py-4">
                  <div className="h-4 bg-blue-500/20 rounded w-24"></div>
                </td>
                <td className="px-6 py-4">
                  <div className="h-4 bg-blue-500/20 rounded w-16"></div>
                </td>
                <td className="px-6 py-4">
                  <div className="h-4 bg-blue-500/20 rounded w-20"></div>
                </td>
                <td className="px-6 py-4">
                  <div className="h-4 bg-blue-500/20 rounded w-32"></div>
                </td>
                <td className="px-6 py-4">
                  <div className="h-4 bg-blue-500/20 rounded w-24"></div>
                </td>
                <td className="px-6 py-4">
                  <div className="h-4 bg-blue-500/20 rounded w-16"></div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )
  }

  if (typeof records === 'undefined') {
    return (
      <div className="glass-morphism rounded-lg p-8">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
          <span className="ml-3 text-blue-200">Loading records...</span>
        </div>
      </div>
    )
  }

  if (!records.length) {
    return (
      <div className="text-center py-12 glass-morphism rounded-lg">
        <p className="text-blue-200">No records found</p>
      </div>
    )
  }

  return (
    <div className="glass-morphism rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-blue-500/20">
          <thead className="bg-blue-900/20">
            <tr>
              <th 
                onClick={() => handleSort('date')}
                className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider cursor-pointer hover:bg-blue-900/40"
              >
                <div className="flex items-center space-x-1">
                  <span>Date</span>
                  {sortField === 'date' && (
                    <span className="text-blue-400">
                      {sortDirection === 'asc' ? '↑' : '↓'}
                    </span>
                  )}
                </div>
              </th>
              <th 
                onClick={() => handleSort('overtime')}
                className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider cursor-pointer hover:bg-blue-900/40"
              >
                <div className="flex items-center space-x-1">
                  <span>Overtime</span>
                  {sortField === 'overtime' && (
                    <span className="text-blue-400">
                      {sortDirection === 'asc' ? '↑' : '↓'}
                    </span>
                  )}
                </div>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                Job Order
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                Destination
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                Details
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-blue-500/20">
            {sortedRecords.map(record => (
              <tr 
                key={record.id}
                className={`hover:bg-blue-900/20 transition-colors ${selectedRecord === record.id ? 'bg-blue-900/30' : ''}`}
                onClick={() => setSelectedRecord(record.id === selectedRecord ? null : record.id)}
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-200">
                  {formatDate(record.date)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-200">
                  {record.overtime ? `${record.overtime} hrs` : '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-200">
                  {record.job_order_no || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-200">
                  {record.destination || '-'}
                </td>
                <td className="px-6 py-4 text-sm text-blue-200">
                  {selectedRecord === record.id ? (
                    <div className="space-y-2">
                      <p><span className="font-medium">Destination:</span> {record.destination || '-'}</p>
                      <p><span className="font-medium">Remarks:</span> {record.remarks || '-'}</p>
                      <p><span className="font-medium">Prepared by:</span> {record.prepared_by || '-'}</p>
                      <p><span className="font-medium">Checked by:</span> {record.checked_by || '-'}</p>
                      <p className="text-xs text-blue-300/40">
                        Created: {new Date(record.created_at || '').toLocaleString()}
                      </p>
                    </div>
                  ) : (
                    <button 
                      className="text-blue-400 hover:text-blue-300"
                      onClick={(e) => {
                        e.stopPropagation()
                        setSelectedRecord(record.id)
                      }}
                    >
                      View Details
                    </button>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      if (confirm('Are you sure you want to delete this record?')) {
                        onDelete(record.id)
                      }
                    }}
                    className="text-red-400 hover:text-red-300"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {sortedRecords.length === 0 && (
        <div className="text-center py-12">
          <p className="text-blue-200/70 text-sm">No attendance records found</p>
        </div>
      )}
    </div>
  )
} 